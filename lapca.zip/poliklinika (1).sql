-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 24 2025 г., 23:25
-- Версия сервера: 8.0.30
-- Версия PHP: 8.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `poliklinika`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Departments`
--

CREATE TABLE `Departments` (
  `DepartmentID` int NOT NULL,
  `DepartmentName` varchar(100) NOT NULL,
  `Floor` int DEFAULT NULL,
  `Rooms` varchar(100) DEFAULT NULL,
  `HeadDoctor` varchar(100) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `Description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- --------------------------------------------------------

--
-- Структура таблицы `Diagnoses`
--

CREATE TABLE `Diagnoses` (
  `DiagnosisID` int NOT NULL,
  `DiagnosisName` varchar(100) NOT NULL,
  `Symptoms` text,
  `Duration` varchar(50) DEFAULT NULL,
  `Treatment` text,
  `IsChronic` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Diagnoses`
--

INSERT INTO `Diagnoses` (`DiagnosisID`, `DiagnosisName`, `Symptoms`, `Duration`, `Treatment`, `IsChronic`) VALUES
(1, 'ывввв', NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `Doctors`
--

CREATE TABLE `Doctors` (
  `DoctorID` int NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `MiddleName` varchar(50) DEFAULT NULL,
  `Specialty` varchar(50) NOT NULL,
  `Experience` int DEFAULT NULL,
  `Qualification` varchar(100) DEFAULT NULL,
  `Phone` varchar(20) DEFAULT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `DepartmentID` int DEFAULT NULL,
  `Photo` varchar(100) DEFAULT NULL,
  `Schedule` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Doctors`
--

INSERT INTO `Doctors` (`DoctorID`, `LastName`, `FirstName`, `MiddleName`, `Specialty`, `Experience`, `Qualification`, `Phone`, `Email`, `DepartmentID`, `Photo`, `Schedule`) VALUES
(1, 'Иванов', 'Иван', 'Иванович', 'Педиатр', NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'Петрова', 'Мария', 'Сергеевна', 'Хирург', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `MedicalRecords`
--

CREATE TABLE `MedicalRecords` (
  `RecordID` int NOT NULL,
  `PatientID` int NOT NULL,
  `DoctorID` int NOT NULL,
  `DiagnosisID` int NOT NULL,
  `RecordDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `TreatmentDetails` text,
  `StartDate` date DEFAULT NULL,
  `EndDate` date DEFAULT NULL,
  `TreatmentType` enum('Амбулаторное','Стационарное','Дневной стационар') DEFAULT NULL,
  `Recommendations` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `MedicalRecords`
--

INSERT INTO `MedicalRecords` (`RecordID`, `PatientID`, `DoctorID`, `DiagnosisID`, `RecordDate`, `TreatmentDetails`, `StartDate`, `EndDate`, `TreatmentType`, `Recommendations`) VALUES
(1, 1, 1, 1, '2025-04-19 22:18:56', NULL, '2025-04-01', '2025-04-01', NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `Patients`
--

CREATE TABLE `Patients` (
  `PatientID` int NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `MiddleName` varchar(50) DEFAULT NULL,
  `BirthDate` date NOT NULL,
  `Address` varchar(100) NOT NULL,
  `City` varchar(50) NOT NULL,
  `Gender` enum('Мужской','Женский') NOT NULL,
  `RegistrationDate` datetime DEFAULT CURRENT_TIMESTAMP,
  `Phone` varchar(20) NOT NULL,
  `Email` varchar(100) DEFAULT NULL,
  `InsuranceNumber` varchar(20) DEFAULT NULL,
  `ParentFullName` varchar(100) NOT NULL,
  `ParentPhone` varchar(20) NOT NULL,
  `ParentRelationship` varchar(50) DEFAULT NULL,
  `BloodType` enum('I','II','III','IV') DEFAULT NULL,
  `RhFactor` enum('+','-') DEFAULT NULL,
  `Allergies` text,
  `ChronicDiseases` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Patients`
--

INSERT INTO `Patients` (`PatientID`, `LastName`, `FirstName`, `MiddleName`, `BirthDate`, `Address`, `City`, `Gender`, `RegistrationDate`, `Phone`, `Email`, `InsuranceNumber`, `ParentFullName`, `ParentPhone`, `ParentRelationship`, `BloodType`, `RhFactor`, `Allergies`, `ChronicDiseases`) VALUES
(1, 'фывфывфыв', 'фвыфвфы', 'вфывфыв', '2021-04-19', 'фыфывфывфыв', 'фывфывфывфыв', 'Мужской', '2025-04-19 22:18:56', '21444214124', 'ythjtyh@hghgh', NULL, 'цвцвцвцв', '1214242424', NULL, NULL, NULL, NULL, NULL),
(2, 'пкауай', 'йцвцйвцйвйцв', 'йцвйцвйцвйцв', '2024-04-19', 'ывфывфы', 'фывфывфывфыв', 'Женский', '2025-04-19 22:30:09', '+7382838123', 'ythjtyh@hghgh', NULL, 'цвцвцвцв', '1214242424', NULL, NULL, NULL, NULL, NULL),
(3, 'пкауай', 'йцвцйвцйвйцв', 'йцвйцвйцвйцв', '2024-04-19', 'ывфывфы', 'фывфывфывфыв', 'Женский', '2025-04-19 22:30:26', '+7382838123', 'ythjtyh@hghgh', NULL, 'цвцвцвцв', '1214242424', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `Users`
--

CREATE TABLE `Users` (
  `UserID` int NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(255) NOT NULL,
  `Email` varchar(100) NOT NULL,
  `Role` enum('admin','doctor','reception') NOT NULL,
  `DoctorID` int DEFAULT NULL,
  `LastLogin` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Users`
--

INSERT INTO `Users` (`UserID`, `Username`, `Password`, `Email`, `Role`, `DoctorID`, `LastLogin`) VALUES
(2, 'receptionist', '$2y$10$LQ7Ae.YAQK929.kMBOUNau1aYS3VN5U3hTIETpB5EPwzx3KKdj6Lm', 'reception@clinic.ru', 'reception', NULL, NULL);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `Departments`
--
ALTER TABLE `Departments`
  ADD PRIMARY KEY (`DepartmentID`);

--
-- Индексы таблицы `Diagnoses`
--
ALTER TABLE `Diagnoses`
  ADD PRIMARY KEY (`DiagnosisID`);

--
-- Индексы таблицы `Doctors`
--
ALTER TABLE `Doctors`
  ADD PRIMARY KEY (`DoctorID`),
  ADD KEY `DepartmentID` (`DepartmentID`);

--
-- Индексы таблицы `MedicalRecords`
--
ALTER TABLE `MedicalRecords`
  ADD PRIMARY KEY (`RecordID`),
  ADD KEY `PatientID` (`PatientID`),
  ADD KEY `DoctorID` (`DoctorID`),
  ADD KEY `DiagnosisID` (`DiagnosisID`);

--
-- Индексы таблицы `Patients`
--
ALTER TABLE `Patients`
  ADD PRIMARY KEY (`PatientID`),
  ADD UNIQUE KEY `InsuranceNumber` (`InsuranceNumber`);

--
-- Индексы таблицы `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`UserID`),
  ADD UNIQUE KEY `Username` (`Username`),
  ADD UNIQUE KEY `Email` (`Email`),
  ADD KEY `DoctorID` (`DoctorID`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `Departments`
--
ALTER TABLE `Departments`
  MODIFY `DepartmentID` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `Diagnoses`
--
ALTER TABLE `Diagnoses`
  MODIFY `DiagnosisID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `Doctors`
--
ALTER TABLE `Doctors`
  MODIFY `DoctorID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `MedicalRecords`
--
ALTER TABLE `MedicalRecords`
  MODIFY `RecordID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `Patients`
--
ALTER TABLE `Patients`
  MODIFY `PatientID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `Users`
--
ALTER TABLE `Users`
  MODIFY `UserID` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `Doctors`
--
ALTER TABLE `Doctors`
  ADD CONSTRAINT `doctors_ibfk_1` FOREIGN KEY (`DepartmentID`) REFERENCES `Departments` (`DepartmentID`);

--
-- Ограничения внешнего ключа таблицы `MedicalRecords`
--
ALTER TABLE `MedicalRecords`
  ADD CONSTRAINT `medicalrecords_ibfk_1` FOREIGN KEY (`PatientID`) REFERENCES `Patients` (`PatientID`),
  ADD CONSTRAINT `medicalrecords_ibfk_2` FOREIGN KEY (`DoctorID`) REFERENCES `Doctors` (`DoctorID`),
  ADD CONSTRAINT `medicalrecords_ibfk_3` FOREIGN KEY (`DiagnosisID`) REFERENCES `Diagnoses` (`DiagnosisID`);

--
-- Ограничения внешнего ключа таблицы `Users`
--
ALTER TABLE `Users`
  ADD CONSTRAINT `users_ibfk_1` FOREIGN KEY (`DoctorID`) REFERENCES `Doctors` (`DoctorID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
