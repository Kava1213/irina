<?php
include 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'reception') {
    header('Location: login.php');
    exit();
}

try {
    $doctors = $pdo->query("SELECT DoctorID, LastName, FirstName, MiddleName FROM Doctors")->fetchAll();
} catch (PDOException $e) {
    die("Ошибка при загрузке врачей: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Новая история болезни</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="#">Детская поликлиника №1</a>
            <div class="d-flex align-items-center">
                <span class="text-white me-3"><?= $_SESSION['user_id'] ?></span>
                <a href="logout.php" class="btn btn-light btn-sm">Выйти</a>
            </div>
        </div>
    </nav>

    <div class="main-container">
        <div class="container">
            <div class="card p-4">
                <h2 class="mb-4"><i class="bi bi-file-medical me-2"></i>Новая история болезни</h2>
                
                <form action="submit.php" method="POST">
                    <div class="row g-3">
                        <!-- Левая колонка -->
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Фамилия</label>
                                <input type="text" name="last_name" class="form-control" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Имя</label>
                                <input type="text" name="first_name" class="form-control" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Отчество</label>
                                <input type="text" name="middle_name" class="form-control">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Адрес</label>
                                <input type="text" name="address" class="form-control" required>
                            </div>
                        </div>
	<div class="mb-3">
    <label class="form-label">Город</label>
    <input type="text" name="city" class="form-control" required>
</div>

<div class="mb-3">
    <label class="form-label">ФИО родителя</label>
    <input type="text" name="parent_full_name" class="form-control" required>
</div>

<div class="mb-3">
    <label class="form-label">Телефон родителя</label>
    <input type="tel" name="parent_phone" class="form-control" required>
</div>

                        <!-- Правая колонка -->
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Телефон</label>
                                <input type="tel" name="phone" class="form-control" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Email</label>
                                <input type="email" name="email" class="form-control">
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Возраст</label>
                                <input type="number" name="age" class="form-control" min="0" required>
                            </div>
                            
                            <div class="mb-3">
                                <label class="form-label">Пол</label>
                                <select name="gender" class="form-select" required>
                                    <option value="Мужской">Мужской</option>
                                    <option value="Женский">Женский</option>
                                </select>
                            </div>
                        </div>
                    </div>

                    <!-- Блок врача и диагноза -->
                    <div class="row g-3 mt-2">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Лечащий врач</label>
                                <select name="doctor_id" class="form-select" required>
                                    <?php foreach ($doctors as $doctor): ?>
                                        <option value="<?= $doctor['DoctorID'] ?>">
                                            <?= "{$doctor['LastName']} {$doctor['FirstName']} {$doctor['MiddleName']}" ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Диагноз</label>
                                <input type="text" name="diagnosis" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <!-- Даты -->
                    <div class="row g-3 mt-2">
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Дата лечения</label>
                                <input type="date" name="treatment_date" class="form-control" required>
                            </div>
                        </div>
                        
                        <div class="col-md-6">
                            <div class="mb-3">
                                <label class="form-label">Дата выздоровления</label>
                                <input type="date" name="recovery_date" class="form-control" required>
                            </div>
                        </div>
                    </div>

                    <button type="submit" class="btn btn-primary mt-4 w-100">
                        <i class="bi bi-save me-2"></i>Сохранить историю болезни
                    </button>
                </form>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container text-center">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <h5>Контакты</h5>
                    <p>Телефон: +7 (495) 123-45-67</p>
                </div>
                <div class="col-md-4 mb-3">
                    <h5>Адрес</h5>
                    <p>ул. Шафиева, 26, Уфа, Респ. Башкортостан.</p>
                </div>
                <div class="col-md-4">
                    <h5>Часы работы</h5>
                    <p>Пн-Пт: 8:00 - 20:00<br>Сб-Вс: 9:00 - 18:00</p>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>