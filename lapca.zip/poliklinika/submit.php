<?php
include 'config.php';

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'reception') {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Получение данных из формы
    $lastName = $_POST['last_name'];
    $firstName = $_POST['first_name'];
    $middleName = $_POST['middle_name'] ?? '';
    $address = $_POST['address'];
    $city = $_POST['city'];
    $phone = $_POST['phone'];
    $email = $_POST['email'] ?? '';
    $parentFullName = $_POST['parent_full_name'];
    $parentPhone = $_POST['parent_phone'];
    $diagnosisName = $_POST['diagnosis'];
    $age = (int)$_POST['age'];
    $gender = $_POST['gender'];
    $doctorId = (int)$_POST['doctor_id'];
    $treatmentDate = $_POST['treatment_date'];
    $recoveryDate = $_POST['recovery_date'];

    // Получение ФИО врача
    try {
        $stmt = $pdo->prepare("SELECT LastName, FirstName, MiddleName FROM Doctors WHERE DoctorID = ?");
        $stmt->execute([$doctorId]);
        $doctor = $stmt->fetch();
        
        if (!$doctor) {
            throw new Exception("Врач с ID $doctorId не найден");
        }
        
        $doctorFullName = trim("{$doctor['LastName']} {$doctor['FirstName']} {$doctor['MiddleName']}");
    } catch (PDOException $e) {
        die("Ошибка при получении данных врача: " . $e->getMessage());
    }

    // Сохранение в TXT
    $content = "ФИО: $lastName $firstName $middleName\n";
    $content .= "Адрес: $address, $city\n";
    $content .= "Телефон: $phone\n";
    $content .= "Email: $email\n";
    $content .= "ФИО родителя: $parentFullName\n";
    $content .= "Телефон родителя: $parentPhone\n";
    $content .= "Возраст: $age\n";
    $content .= "Пол: $gender\n";
    $content .= "Диагноз: $diagnosisName\n";
    $content .= "Лечащий врач: $doctorFullName\n"; // Исправлено: ФИО вместо ID
    $content .= "Дата лечения: $treatmentDate\n";
    $content .= "Дата выздоровления: $recoveryDate\n";

    try {
        // Создание папки records, если её нет
        if (!is_dir('records')) {
            if (!mkdir('records', 0777, true)) {
                throw new Exception("Не удалось создать папку 'records'");
            }
        }

        // Сохранение файла
        $filename = "records/patient_" . time() . ".txt"; // Уникальное имя файла
        if (!file_put_contents($filename, $content)) {
            throw new Exception("Ошибка при сохранении файла");
        }

        // ... остальной код (сохранение в БД) ...

        header('Location: index.php?success=1');
    } catch (Exception $e) {
        die("Ошибка: " . $e->getMessage());
    }
}
?>