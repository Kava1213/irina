<?php
include 'config.php';

$username = 'receptionist';
$password = password_hash('password123', PASSWORD_DEFAULT);
$email = 'reception@clinic.ru';
$role = 'reception';

try {
    $stmt = $pdo->prepare("
        INSERT INTO Users (Username, Password, Email, Role) 
        VALUES (?, ?, ?, ?)
    ");
    $stmt->execute([$username, $password, $email, $role]);
    echo "Пользователь создан! Удалите этот файл.";
} catch (PDOException $e) {
    die("Ошибка: " . $e->getMessage());
}
?>